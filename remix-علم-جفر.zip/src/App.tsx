/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { Copy, RefreshCw, Sparkles, MessageCircle, FileText, Volume2, Square, Moon, Sun, History, X } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { motion } from 'motion/react';

const ABJAD_VALUES: Record<string, number> = {
    'ا': 1, 'آ': 1, 'ب': 2, 'پ': 2, 'ج': 3, 'چ': 3, 'د': 4, 'ڈ': 4, 'ہ': 5, 'ة': 5,
    'و': 6, 'ؤ': 6, 'ز': 7, 'ژ': 7, 'ح': 8, 'ط': 9, 'ی': 10, 'ے': 10, 'ئ': 10,
    'ک': 20, 'گ': 20, 'ل': 30, 'م': 40, 'ن': 50, 'س': 60, 'ع': 70, 'ف': 80,
    'ص': 90, 'ق': 100, 'ر': 200, 'ڑ': 200, 'ش': 300, 'ت': 400, 'ٹ': 400,
    'ث': 500, 'خ': 600, 'ذ': 700, 'ض': 800, 'ظ': 900, 'غ': 1000
};

const MysticSparkles = ({ count = 20 }) => {
    return (
        <div className="absolute inset-0 pointer-events-none z-10 overflow-visible">
            {Array.from({ length: count }).map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-[3px] h-[3px] bg-yellow-300 rounded-full"
                    initial={{
                        opacity: 1,
                        scale: 0,
                        x: "50%",
                        y: "50%",
                    }}
                    animate={{
                        opacity: [1, 0],
                        scale: [0, 2, 0],
                        x: `${50 + (Math.random() - 0.5) * 400}%`,
                        y: `${50 + (Math.random() - 0.5) * 400}%`,
                    }}
                    transition={{
                        duration: 1.5 + Math.random(),
                        ease: "easeOut",
                    }}
                />
            ))}
        </div>
    );
};

function calculateMufred(n: number): number {
    if (n === 0) return 0;
    while (n > 9) {
        n = n.toString().split('').reduce((a, b) => a + parseInt(b, 10), 0);
    }
    return n;
}

export default function App() {
    const [query, setQuery] = useState('');
    const [activeGap, setActiveGap] = useState(1);
    
    // Results state
    const [isCalculated, setIsCalculated] = useState(false);
    const [results, setResults] = useState<{
        letterCount: number;
        abjadSum: number;
        grid: { char: string; highlight: boolean; val: number }[][];
        finalLetters: string[];
        totalSum: number;
        mufred: number;
    } | null>(null);

    // AI state
    const [aiLoading, setAiLoading] = useState(false);
    const [aiResult, setAiResult] = useState('');
    const [aiResponseTextForShare, setAiResponseTextForShare] = useState('');
    const [isPlayingTTS, setIsPlayingTTS] = useState(false);

    // Theme & History state
    const [theme, setTheme] = useState<'dark' | 'light'>('dark');
    const [showHistory, setShowHistory] = useState(false);
    const [history, setHistory] = useState<any[]>([]);

    // PWA Install state
    const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

    useEffect(() => {
        const handleBeforeInstallPrompt = (e: any) => {
            e.preventDefault();
            setDeferredPrompt(e);
        };
        
        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        
        return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    }, []);

    const handleInstallClick = async () => {
        if (!deferredPrompt) return;
        
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            setDeferredPrompt(null);
        }
    };

    useEffect(() => {
        const savedTheme = localStorage.getItem('ilmejafar_theme');
        if (savedTheme === 'light') {
            setTheme('light');
            document.body.classList.add('light-theme');
        }
        
        const savedHistory = localStorage.getItem('ilmejafar_history');
        if (savedHistory) {
            try {
                setHistory(JSON.parse(savedHistory));
            } catch (e) {}
        }
    }, []);

    const toggleTheme = () => {
        if (theme === 'dark') {
            setTheme('light');
            document.body.classList.add('light-theme');
            localStorage.setItem('ilmejafar_theme', 'light');
        } else {
            setTheme('dark');
            document.body.classList.remove('light-theme');
            localStorage.setItem('ilmejafar_theme', 'dark');
        }
    };

    const saveToHistory = (res: any, queryStr: string, gap: number, aiText: string = '') => {
        setHistory(prev => {
            const existingItem = prev.find(item => item.query === queryStr && item.activeGap === gap);
            const newEntry = {
                id: existingItem ? existingItem.id : Date.now(),
                date: existingItem ? existingItem.date : new Date().toLocaleString('ur-PK'),
                query: queryStr,
                activeGap: gap,
                results: res,
                aiResponse: aiText || (existingItem ? existingItem.aiResponse : ''),
                note: existingItem ? existingItem.note : ''
            };
            const filtered = prev.filter(item => item.query !== queryStr || item.activeGap !== gap);
            const newHistory = [newEntry, ...filtered].slice(0, 20); // keep last 20
            localStorage.setItem('ilmejafar_history', JSON.stringify(newHistory));
            return newHistory;
        });
    };

    const updateHistoryNote = (id: number, note: string) => {
        setHistory(prev => {
            const newHistory = prev.map(item => item.id === id ? { ...item, note } : item);
            localStorage.setItem('ilmejafar_history', JSON.stringify(newHistory));
            return newHistory;
        });
    };

    const loadHistoryItem = (item: any) => {
        setQuery(item.query);
        setActiveGap(item.activeGap);
        setResults(item.results);
        setAiResponseTextForShare(item.aiResponse || '');
        setAiResult(item.aiResponse || '');
        setIsCalculated(true);
        setShowHistory(false);
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        setIsPlayingTTS(false);
    };

    const deleteHistoryItem = (id: number, e: React.MouseEvent) => {
        e.stopPropagation();
        setHistory(prev => {
            const newHistory = prev.filter(item => item.id !== id);
            localStorage.setItem('ilmejafar_history', JSON.stringify(newHistory));
            return newHistory;
        });
    };

    // Toast state
    const [toastMsg, setToastMsg] = useState('');

    const showToast = (msg: string) => {
        setToastMsg(msg);
        setTimeout(() => setToastMsg(''), 3000);
    };

    const runCalculation = () => {
        if (!query.trim()) {
            clearAll();
            return;
        }

        const queryNoSpaces = query.replace(/\s+/g, '');
        const letterCount = queryNoSpaces.length;
        
        let abjadSum = 0;
        for (let i = 0; i < queryNoSpaces.length; i++) {
            abjadSum += ABJAD_VALUES[queryNoSpaces[i]] || 0;
        }

        const words = query.trim().split(/\s+/);
        let maxLen = 0;
        words.forEach(w => { if(w.length > maxLen) maxLen = w.length; });

        const grid: { char: string; highlight: boolean; val: number }[][] = [];
        const finalLetters: string[] = [];
        let charCounter = 0;
        let totalSum = 0;

        for (let r = 0; r < maxLen; r++) {
            const row: { char: string; highlight: boolean; val: number }[] = [];
            for (let c = 0; c < words.length; c++) {
                const char = words[c][r] || '';
                let highlight = false;
                let val = 0;
                
                if (char !== '') {
                    charCounter++;
                    if (charCounter % activeGap === 0) {
                        highlight = true;
                        val = ABJAD_VALUES[char] || 0;
                        totalSum += val;
                        finalLetters.push(char);
                    }
                }
                row.push({ char, highlight, val });
            }
            grid.push(row);
        }

        const mufred = calculateMufred(totalSum);
        
        const newResults = { letterCount, abjadSum, grid, finalLetters, totalSum, mufred };
        setResults(newResults);
        setIsCalculated(true);
        setAiResult('');
        setAiResponseTextForShare('');
    };

    // Auto-calculate on input or gap change
    useEffect(() => {
        if (query.trim() !== "") {
            runCalculation();
        } else {
            clearAll();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [query, activeGap]);

    useEffect(() => {
        return () => {
            if (window.speechSynthesis) {
                window.speechSynthesis.cancel();
            }
        };
    }, []);

    const clearAll = () => {
        setQuery('');
        setIsCalculated(false);
        setResults(null);
        setAiResult('');
        setAiResponseTextForShare('');
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        setIsPlayingTTS(false);
    };

    const copyToClip = () => {
        if (!results || results.finalLetters.length === 0) return;
        const text = results.finalLetters.join(' ');
        navigator.clipboard.writeText(text);
        showToast('✅ اخذ کردہ حروف کاپی ہو گئے!');
    };

    const generateAIAnalysis = async () => {
        if (!results || results.finalLetters.length === 0 || !query) {
            showToast("⚠️ براہ کرم پہلے سوال درج کریں اور حروف اخذ ہونے دیں۔");
            return;
        }

        setAiLoading(true);
        setAiResult('');
        
        try {
            const res = await fetch('/api/analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    originalQuery: query,
                    lettersStr: results.finalLetters.join(' - ')
                })
            });
            const data = await res.json();
            
            if (res.ok && data.text) {
                setAiResponseTextForShare(data.text);
                setAiResult(data.text);
                saveToHistory(results, query, activeGap, data.text);
            } else {
                setAiResult(data.error || 'معذرت، تفسير حاصل کرنے میں دشواری ہو رہی ہے۔ دوبارہ کوشش کریں۔');
            }
        } catch (error) {
            setAiResult('نیٹ ورک کے عارضی مسئلے کی وجہ سے تفسیر مکمل نہ ہو سکی۔ دوبارہ کوشش کریں۔');
        } finally {
            setAiLoading(false);
        }
    };

    const copyAIText = () => {
        if (!aiResponseTextForShare) return;
        const shareText = `*علم جفر - استخراج و استنطاق*\n\n*سوال:* ${query}\n\n*تفسیر:*\n${aiResponseTextForShare}`;
        navigator.clipboard.writeText(shareText);
        showToast('✅ جفری تفسیر کامیابی سے کاپی ہو گئی!');
    };

    const shareWhatsApp = () => {
        if (!aiResponseTextForShare) {
            showToast('⚠️ براہ کرم پہلے تفسیر حاصل کریں!');
            return;
        }
        const shareText = `*علم جفر - استخراج و استنطاق*\n\n*سوال:* ${query}\n\n*تفسیر:*\n${aiResponseTextForShare}`;
        const encodedText = encodeURIComponent(shareText);
        window.open(`https://api.whatsapp.com/send?text=${encodedText}`, '_blank');
    };

    const downloadPDF = async () => {
        if (!aiResponseTextForShare) {
            showToast('⚠️ براہ کرم پہلے تفسیر حاصل کریں!');
            return;
        }
        showToast('پی ڈی ایف تیار ہو رہی ہے، براہ کرم انتظار کریں...');
        
        try {
            const tempDiv = document.createElement('div');
            tempDiv.style.position = 'absolute';
            tempDiv.style.left = '-9999px';
            tempDiv.style.top = '0';
            tempDiv.style.width = '800px';
            tempDiv.style.padding = '40px';
            tempDiv.style.backgroundColor = '#ffffff';
            tempDiv.style.color = '#000000';
            tempDiv.style.fontFamily = '"Noto Nastaliq Urdu", serif';
            tempDiv.style.direction = 'rtl';
            tempDiv.style.fontSize = '24px';
            tempDiv.style.lineHeight = '2.5';
            
            tempDiv.innerHTML = `
                <h1 style="color: #000000; text-align: center; margin-bottom: 30px;">علمِ جفر (استخراج و استنطاق)</h1>
                <p><strong style="color: #000000;">سوال:</strong> ${query}</p>
                <p><strong style="color: #000000;">اخذ کردہ حروف:</strong> ${results?.finalLetters.join(' - ')}</p>
                <p><strong style="color: #000000;">مفرد عدد:</strong> ${results?.mufred}</p>
                <p><strong style="color: #000000;">تفسیر:</strong></p>
                <div style="white-space: pre-wrap;">${aiResponseTextForShare}</div>
            `;
            
            document.body.appendChild(tempDiv);
            
            const canvas = await html2canvas(tempDiv, { scale: 2 });
            document.body.removeChild(tempDiv);
            
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pageHeight = pdf.internal.pageSize.getHeight();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
            
            let heightLeft = pdfHeight;
            let position = 0;
            
            pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
            heightLeft -= pageHeight;
            
            while (heightLeft > 0) {
                position -= pageHeight;
                pdf.addPage();
                pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
                heightLeft -= pageHeight;
            }
            
            pdf.save('Ilme_Jafar_Analysis.pdf');
            
            showToast('✅ پی ڈی ایف کامیابی سے ڈاؤن لوڈ ہو گئی!');
        } catch (error) {
            console.error(error);
            showToast('⚠️ پی ڈی ایف بنانے میں مسئلہ پیش آیا۔');
        }
    };

    const toggleTTS = () => {
        if (!window.speechSynthesis) {
            showToast('⚠️ آپ کا براؤزر ٹیکسٹ ٹو اسپیچ کو سپورٹ نہیں کرتا۔');
            return;
        }

        if (isPlayingTTS) {
            window.speechSynthesis.cancel();
            setIsPlayingTTS(false);
            return;
        }

        if (!aiResponseTextForShare) {
            showToast('⚠️ پڑھنے کے لیے کوئی متن نہیں ہے۔');
            return;
        }

        setIsPlayingTTS(true);
        
        // Split text into chunks to avoid browser TTS timeout/cut-off for long texts
        const textToRead = aiResponseTextForShare;
        
        // Split by Urdu sentence terminators, periods, newlines, etc.
        const chunks = textToRead.match(/[^.!?\n۔]+[.!?\n۔]+/g) || [textToRead];
        
        const finalChunks: string[] = [];
        chunks.forEach(chunk => {
            if (chunk.length > 120) {
                const words = chunk.split(' ');
                let current = '';
                words.forEach(word => {
                    if ((current + word).length > 120) {
                        finalChunks.push(current);
                        current = word + ' ';
                    } else {
                        current += word + ' ';
                    }
                });
                if (current.trim()) finalChunks.push(current);
            } else {
                if (chunk.trim()) finalChunks.push(chunk);
            }
        });

        if (finalChunks.length === 0) {
            setIsPlayingTTS(false);
            return;
        }

        finalChunks.forEach((chunk, index) => {
            const utterance = new SpeechSynthesisUtterance(chunk.trim());
            utterance.lang = 'ur-PK'; // Urdu
            utterance.rate = 0.9;
            
            if (index === finalChunks.length - 1) {
                utterance.onend = () => {
                    setIsPlayingTTS(false);
                };
            }
            
            utterance.onerror = (e) => {
                // Ignore cancel errors as they are triggered by our own cancel button
                if (e.error !== 'canceled' && e.error !== 'interrupted') {
                    console.error('TTS Error:', e);
                    setIsPlayingTTS(false);
                }
            };

            window.speechSynthesis.speak(utterance);
        });
    };

    return (
        <div className="w-full max-w-[800px] mx-auto min-h-screen px-0 sm:px-4 pt-0 sm:pt-6 pb-0 sm:pb-10 flex flex-col box-border relative">
            <div className="flex justify-between items-center p-4 sm:px-0 mb-2">
                <button
                    onClick={() => setShowHistory(true)}
                    className="p-2 rounded-full bg-black/30 border border-[var(--glass-border)] text-[var(--gold-bright)] hover:bg-[var(--gold-bright)] hover:text-[#01140e] transition-all"
                    title="تاریخ (History)"
                >
                    <History size={24} />
                </button>
                
                <div className="flex items-center gap-3">
                    {deferredPrompt && (
                        <button
                            onClick={handleInstallClick}
                            className="px-4 py-2 rounded-full bg-[rgba(6,182,212,0.15)] border border-[var(--primary-accent)]/30 text-[var(--primary-accent)] font-bold hover:bg-[var(--primary-accent)] hover:text-white transition-all text-sm"
                        >
                            ایپ انسٹال کریں
                        </button>
                    )}
                    <button
                        onClick={toggleTheme}
                        className="p-2 rounded-full bg-black/30 border border-[var(--glass-border)] text-[var(--gold-bright)] hover:bg-[var(--gold-bright)] hover:text-[#01140e] transition-all"
                        title="Theme Toggle"
                    >
                        {theme === 'dark' ? <Sun size={24} /> : <Moon size={24} />}
                    </button>
                </div>
            </div>

            <h1 className="text-center text-[2.3rem] mb-[30px] font-bold text-[var(--gold-bright)] relative pb-5" style={{ textShadow: '0 0 20px var(--gold-glow)' }}>
                علمِ جفر (استخراج و استنطاق)
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[160px] h-[3px] bg-gradient-to-r from-transparent via-[var(--gold-bright)] to-transparent rounded-sm"></span>
            </h1>

            <div className="relative">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="اپنا سوال یا حروف یہاں درج کریں..."
                    autoComplete="off"
                    className="w-full p-5 text-[1.6rem] bg-black/45 border-2 border-[var(--glass-border)] rounded-[20px] text-[var(--gold-bright)] text-center mb-[30px] font-sans outline-none transition-all duration-400 ease-[cubic-bezier(0.4,0,0.2,1)] leading-[2.2] placeholder:text-[rgba(254,243,199,0.4)] focus:border-[var(--gold-bright)] focus:bg-black/60 shadow-[inset_0_4px_15px_rgba(0,0,0,0.6),0_4px_20px_rgba(0,0,0,0.2)]"
                />
            </div>

            <div className="flex justify-center gap-3 mb-[35px] flex-wrap">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                    <button
                        key={i}
                        onClick={() => setActiveGap(i)}
                        className={`w-[52px] h-[52px] border border-[var(--glass-border)] rounded-full flex items-center justify-center text-[1.5rem] font-sans transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-[0_4px_12px_rgba(0,0,0,0.4)]
                        ${activeGap === i 
                            ? 'bg-gradient-to-br from-[var(--gold-bright)] to-[var(--gold-dim)] text-[#01140e] font-[800] border-[var(--gold-bright)] shadow-[0_0_20px_var(--gold-glow)] scale-110' 
                            : 'bg-[#022c2299] text-[var(--text-muted)] font-bold hover:border-[var(--gold-bright)] hover:text-[var(--gold-bright)] hover:-translate-y-[3px] hover:scale-105 hover:shadow-[0_6px_16px_rgba(0,0,0,0.5)]'
                        }`}
                    >
                        {i}
                    </button>
                ))}
            </div>

            {isCalculated && results && (
                <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                    className="flex justify-center mb-6 mt-[-15px] relative"
                >
                    <MysticSparkles key={results.mufred + '-' + Date.now()} count={15} />
                    <div className="bg-[rgba(6,182,212,0.15)] border border-[var(--primary-accent)]/30 text-[var(--primary-accent)] px-6 py-2 rounded-full text-lg font-bold shadow-[0_0_10px_rgba(6,182,212,0.2)] flex items-center gap-3 relative z-20">
                        مفرد عدد: 
                        <span className="text-[var(--gold-bright)] text-2xl drop-shadow-[0_0_5px_var(--gold-glow)]">{results.mufred}</span>
                    </div>
                </motion.div>
            )}

            <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={runCalculation}
                className="w-full p-[18px] text-[20px] font-bold bg-gradient-to-br from-[var(--gold-dim)] to-[var(--gold-bright)] text-[#01140e] rounded-[18px] mb-[15px] transition-shadow shadow-[0_6px_20px_rgba(180,83,9,0.3)] hover:shadow-[0_8px_25px_rgba(251,191,36,0.4)]"
            >
                حساب کریں
            </motion.button>
            <button
                onClick={clearAll}
                className="bg-transparent border-none text-[var(--text-muted)] block mx-auto mt-[15px] mb-[5px] text-[16px] transition-colors duration-300 opacity-80 hover:text-red-500 hover:opacity-100"
            >
                تمام مواد صاف کریں
            </button>

            {isCalculated && results && (
                <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
                    className="glass-panel mt-6 p-6 sm:p-8"
                >
                    
                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 gap-4 mb-[30px]">
                        <div className="bg-black/40 border border-[var(--glass-border)] rounded-[20px] p-5 text-center transition-transform duration-300 hover:-translate-y-1 hover:border-[var(--primary-accent)]">
                            <p className="text-sm text-[var(--text-muted)] font-sans mb-2 tracking-wider">حروف کی تعداد</p>
                            <p className="text-4xl font-bold text-white font-sans">{results.letterCount}</p>
                        </div>
                        <div className="bg-black/40 border border-[var(--glass-border)] rounded-[20px] p-5 text-center transition-transform duration-300 hover:-translate-y-1 hover:border-[var(--primary-accent)]">
                            <p className="text-sm text-[var(--text-muted)] font-sans mb-2 tracking-wider">سوال کے کل اعداد</p>
                            <p className="text-4xl font-bold text-yellow-400 font-sans drop-shadow-md">{results.abjadSum}</p>
                        </div>
                    </div>

                    {/* Result Table */}
                    <div className="overflow-x-auto border-t border-dashed border-[rgba(251,191,36,0.2)] pt-[25px] mb-[35px]">
                        <p className="text-center text-xs text-yellow-500/60 mb-5 tracking-[0.2em] font-sans uppercase">عمودی ترتیب (Vertical Grid)</p>
                        <table className="mx-auto border-collapse border-spacing-[10px]" style={{ borderSpacing: '10px', borderCollapse: 'separate' }}>
                            <tbody>
                                {results.grid.map((row, rIdx) => (
                                    <tr key={rIdx}>
                                        {row.map((cell, cIdx) => (
                                            <motion.td
                                                initial={{ opacity: 0, scale: 0.8, y: 10 }}
                                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                                transition={{ 
                                                    delay: (rIdx * row.length + cIdx) * 0.05, 
                                                    duration: 0.4, 
                                                    type: "spring", 
                                                    stiffness: 100 
                                                }}
                                                key={cIdx}
                                                className={`min-w-[50px] sm:min-w-[65px] h-[60px] sm:h-[75px] text-center text-[1.5rem] sm:text-[2rem] border rounded-[16px] leading-[2.2] transition-all duration-400 ease-[cubic-bezier(0.4,0,0.2,1)]
                                                ${cell.highlight 
                                                    ? 'bg-[rgba(6,182,212,0.15)] font-bold border-[var(--primary-accent)] text-[var(--primary-accent)] shadow-[0_0_15px_rgba(6,182,212,0.3),inset_0_0_8px_rgba(6,182,212,0.2)] scale-105' 
                                                    : 'bg-black/30 border-[rgba(148,163,184,0.15)] text-[var(--text-muted)]'
                                                }`}
                                            >
                                                {cell.char}
                                            </motion.td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Extracted Letters */}
                    <div className="mt-12 text-center">
                        <h3 className="text-yellow-400 text-xl mb-6 inline-block border-b-2 border-yellow-700/40 pb-2">اخذ کردہ حروف</h3>
                        <div className="flex flex-wrap justify-center gap-[14px] mt-5">
                            {results.grid.flat().filter(c => c.highlight).map((cell, idx) => (
                                <motion.div 
                                    initial={{ opacity: 0, scale: 0.5, y: 20 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    transition={{ 
                                        delay: idx * 0.1, 
                                        duration: 0.5, 
                                        type: "spring", 
                                        stiffness: 120 
                                    }}
                                    key={idx} 
                                    className="border border-[var(--primary-accent)]/50 p-[12px_20px] rounded-[18px] bg-gradient-to-br from-[rgba(2,6,23,0.8)] to-[rgba(6,182,212,0.2)] text-center min-w-[75px] shadow-[0_4px_15px_rgba(0,0,0,0.5)] relative overflow-hidden"
                                >
                                    <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[var(--primary-accent)] to-transparent"></div>
                                    <span className="text-3xl block font-bold text-white mb-1">{cell.char}</span>
                                    <span className="text-xs text-[var(--primary-accent)] font-sans px-2 py-0.5 bg-black/40 rounded-full">{cell.val}</span>
                                </motion.div>
                            ))}
                        </div>
                    </div>

                    {/* Mufred Box */}
                    <div className="text-center mt-10 p-[40px_20px] mufred-box border border-[var(--glass-border)] rounded-[24px]">
                        <p className="text-sm text-[var(--text-muted)] font-sans tracking-widest mb-4 uppercase">
                            اخذ کردہ حروف کے کل اعداد: {results.totalSum}
                        </p>
                        <div className="text-[110px] font-[900] leading-none my-[15px] font-sans" 
                             style={{ 
                                 textShadow: '0 0 35px var(--gold-glow)',
                                 background: 'linear-gradient(to bottom, #ffffff, var(--gold-bright))',
                                 WebkitBackgroundClip: 'text',
                                 WebkitTextFillColor: 'transparent'
                             }}>
                            {results.mufred}
                        </div>
                        <p className="font-bold text-[var(--text-main)] text-2xl mt-4">مفرد عدد (روحانی ہندسہ)</p>
                        <button
                            onClick={copyToClip}
                            className="mt-8 text-[var(--primary-accent)] hover:text-cyan-300 text-lg transition-colors flex items-center justify-center gap-2 mx-auto"
                        >
                            <Copy size={20} />
                            اخذ کردہ حروف کاپی کریں
                        </button>
                    </div>

                    {/* AI Section */}
                    <div className="mt-[50px] border-t border-dashed border-[rgba(251,191,36,0.25)] pt-[40px] text-center">
                        <h3 className="text-2xl font-bold mb-3 text-white">جفری تفسیر اور استنطاق</h3>
                        <p className="text-[var(--text-muted)] mb-8 max-w-md mx-auto leading-relaxed">اصل سوال اور حاصل شدہ حروف کے درمیان چھپا ہوا باطنی اور روحانی تعلق جانیں</p>
                        
                        <button
                            onClick={generateAIAnalysis}
                            disabled={aiLoading}
                            className="btn-ai-gradient text-white border border-[var(--primary-accent)] shadow-[0_0_25px_rgba(6,182,212,0.35)] flex items-center justify-center gap-2 rounded-[20px] py-4 text-xl font-bold w-full transition-all disabled:opacity-75 disabled:cursor-not-allowed disabled:animate-pulse-mystic"
                        >
                            {aiLoading ? (
                                <>
                                    <RefreshCw className="animate-spin" size={24} />
                                    روحانی استنطاق و مراقبہ جاری ہے...
                                </>
                            ) : (
                                <>
                                    <Sparkles size={24} />
                                    جواب کی روحانی و جفری تفسیر جانیں
                                </>
                            )}
                        </button>

                        {(aiResult || aiLoading) && (
                            <div className="bg-black/50 border border-[var(--gold-bright)] rounded-[24px] p-3 sm:p-[30px] mt-[25px] text-right text-[1.1rem] sm:text-[1.25rem] leading-[2.2] sm:leading-[2.6] text-[var(--text-main)] shadow-[inset_0_0_25px_rgba(0,0,0,0.7),0_10px_30px_rgba(0,0,0,0.5)]">
                                <div className="text-[var(--gold-bright)] font-bold text-[1.4rem] sm:text-[1.6rem] mb-[15px] sm:mb-[20px] text-center flex items-center justify-center gap-3 before:content-[''] before:h-[1px] before:flex-1 before:bg-gradient-to-r before:from-transparent before:to-[var(--gold-bright)] after:content-[''] after:h-[1px] after:flex-1 after:bg-gradient-to-l after:from-transparent after:to-[var(--gold-bright)]">
                                    تفسیر و مماثلت
                                </div>
                                
                                {!aiLoading && aiResult && (
                                    <div className="flex flex-wrap justify-center gap-2 mb-6">
                                        <button
                                            onClick={copyAIText}
                                            className="px-3 py-1.5 rounded-lg font-bold text-[0.9rem] transition-all flex items-center gap-1.5 bg-[rgba(251,191,36,0.1)] border border-[var(--gold-bright)] text-[var(--gold-bright)] hover:bg-[var(--gold-bright)] hover:text-[#01140e]"
                                        >
                                            <Copy size={16} /> کاپی
                                        </button>
                                        <button
                                            onClick={toggleTTS}
                                            className={`px-3 py-1.5 rounded-lg font-bold text-[0.9rem] transition-all flex items-center gap-1.5 border hover:-translate-y-0.5 ${
                                                isPlayingTTS 
                                                ? 'bg-red-500/20 border-red-500 text-red-400 hover:bg-red-500 hover:text-white' 
                                                : 'bg-[var(--primary-accent)]/20 border-[var(--primary-accent)] text-[var(--primary-accent)] hover:bg-[var(--primary-accent)] hover:text-white'
                                            }`}
                                        >
                                            {isPlayingTTS ? (
                                                <><Square size={16} fill="currentColor" /> روکیں</>
                                            ) : (
                                                <><Volume2 size={16} /> سنیں</>
                                            )}
                                        </button>
                                        <button
                                            onClick={shareWhatsApp}
                                            className="px-3 py-1.5 rounded-lg font-bold text-[0.9rem] transition-all flex items-center gap-1.5 bg-[var(--whatsapp)] text-white hover:bg-[#128C7E] hover:-translate-y-0.5"
                                        >
                                            <MessageCircle size={16} /> واٹس ایپ
                                        </button>
                                        <button
                                            onClick={downloadPDF}
                                            className="px-3 py-1.5 rounded-lg font-bold text-[0.9rem] transition-all flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-red-800 text-white hover:-translate-y-0.5"
                                        >
                                            <FileText size={16} /> پی ڈی ایف
                                        </button>
                                    </div>
                                )}
                                
                                <div className="markdown-body font-sans" dir="rtl">
                                    {aiLoading ? (
                                        <div className="text-center text-[var(--text-muted)] animate-pulse">انتظار فرمائیں...</div>
                                    ) : (
                                        <ReactMarkdown
                                            components={{
                                                strong: ({node, ...props}) => <strong style={{color: 'var(--gold-bright)', fontSize: '1.15em'}} {...props} />,
                                                em: ({node, ...props}) => <em style={{color: 'var(--text-muted)'}} {...props} />,
                                                p: ({node, ...props}) => <p className="mb-4" {...props} />
                                            }}
                                        >
                                            {aiResult}
                                        </ReactMarkdown>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                </motion.div>
            )}

            {toastMsg && (
                <div className="fixed bottom-[40px] left-1/2 -translate-x-1/2 bg-[var(--gold-bright)] text-[#01140e] px-8 py-4 rounded-[30px] font-bold text-[1.1rem] z-[1000] shadow-[0_10px_30px_rgba(0,0,0,0.6)] toast-enter">
                    {toastMsg}
                </div>
            )}

            {/* History Drawer */}
            {showHistory && (
                <div className="fixed inset-0 bg-black/80 z-[2000] flex justify-end" onClick={() => setShowHistory(false)}>
                    <div 
                        className="w-[90%] max-w-[400px] h-full bg-[var(--bg-mystic-dark)] border-l border-[var(--glass-border)] shadow-[-10px_0_30px_rgba(0,0,0,0.8)] flex flex-col animate-slide-in-right p-4 sm:p-6 overflow-y-auto"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center mb-6 pb-4 border-b border-[var(--glass-border)]">
                            <h2 className="text-2xl text-[var(--gold-bright)] font-bold">پچھلی تلاش</h2>
                            <button onClick={() => setShowHistory(false)} className="p-2 bg-black/20 rounded-full text-[var(--text-muted)] hover:bg-black/50 hover:text-red-400 transition-colors">
                                <X size={24} />
                            </button>
                        </div>
                        <div className="flex flex-col gap-4">
                            {history.length === 0 ? (
                                <p className="text-center text-[var(--text-muted)] mt-10">کوئی ریکارڈ نہیں ملا</p>
                            ) : (
                                history.map(item => (
                                    <div key={item.id} className="bg-[var(--glass-bg)] border border-[var(--glass-border)] rounded-2xl p-4 cursor-pointer hover:border-[var(--primary-accent)] hover:shadow-[0_0_15px_rgba(6,182,212,0.15)] transition-all flex flex-col" onClick={() => loadHistoryItem(item)}>
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="text-xs text-[var(--text-muted)] font-sans">{item.date}</span>
                                            <button onClick={(e) => deleteHistoryItem(item.id, e)} className="p-1 text-[var(--text-muted)] hover:text-red-500 rounded-md transition-colors"><X size={18}/></button>
                                        </div>
                                        <p className="text-[var(--gold-bright)] font-bold text-lg mb-1 truncate" dir="rtl">{item.query}</p>
                                        <p className="text-[var(--primary-accent)] text-sm mb-3 font-medium">مفرد عدد: {item.results?.mufred}</p>
                                        
                                        {item.aiResponse && (
                                            <div className="text-[var(--text-muted)] text-xs line-clamp-3 mb-3 border-t border-[var(--glass-border)] pt-3 leading-relaxed" dir="rtl">
                                                <strong className="text-[var(--gold-dim)] ml-1">تفسیر:</strong>
                                                {item.aiResponse.replace(/[*#]/g, '')}
                                            </div>
                                        )}

                                        <div className="mt-auto" onClick={e => e.stopPropagation()}>
                                            <textarea 
                                                className="w-full bg-black/40 border border-[var(--glass-border)] rounded-xl p-3 text-sm text-[var(--text-main)] placeholder-[var(--text-muted)] focus:outline-none focus:border-[var(--primary-accent)] focus:ring-1 focus:ring-[var(--primary-accent)] transition-all resize-none h-[70px]"
                                                placeholder="اپنے نوٹس یہاں لکھیں..."
                                                dir="rtl"
                                                value={item.note || ''}
                                                onChange={(e) => updateHistoryNote(item.id, e.target.value)}
                                            />
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
