import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post("/api/analyze", async (req, res) => {
    try {
      const { originalQuery, lettersStr } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY environment variable is required" });
      }

      const ai = new GoogleGenAI({ apiKey });
      const promptText = `
علم جفر کی روشنی میں درج ذیل کا روحانی اور منطقی تجزیہ کریں:

اصل سوال/الفاظ: "${originalQuery}"
اخذ کردہ حروف: (${lettersStr})

براہ کرم درج ذیل نکات پر تفصیل سے روشنی ڈالیں:
1. ان اخذ کردہ حروف کو ملا کر کون سے بامعنی الفاظ یا اشارے بنتے ہیں؟
2. اصل سوال اور ان حاصل شدہ حروف/الفاظ کے درمیان کیا 'مماثلت' (روحانی یا باطنی تعلق) ہے؟
3. جفر کے اعتبار سے یہ حروف اصل سوال کے حوالے سے کیا چھپا ہوا اشارہ، معنی یا نتیجہ ظاہر کر رہے ہیں؟

جواب خالص، سلیس اور ادبی اردو زبان میں دیں تاکہ پڑھنے والے کو سوال اور جواب کا گہرا اور روحانی تعلق بخوبی سمجھ آ سکے۔
`;

      let responseText = "";
      let retries = 3;
      let currentModel = "gemini-2.5-flash";
      
      while (retries > 0) {
        try {
          const response = await ai.models.generateContent({
            model: currentModel,
            contents: promptText,
            config: {
                systemInstruction: "You are a master of Ilm-e-Jafar and Islamic spiritual linguistics. Analyze the connection between the user's query and the extracted letters, explaining the hidden meaning entirely in beautiful Urdu language. Use Markdown formatting features smoothly.",
            }
          });
          responseText = response.text || "";
          break; // Success
        } catch (e: any) {
          retries--;
          const is429 = e?.message?.includes("429") || e?.status === 429 || e?.code === 429;
          const is503 = e?.message?.includes("503") || e?.status === 503 || e?.code === 503;
          
          if (retries === 0 || (!is503 && !is429)) {
            throw e;
          }
          
          if (is429) {
             if (currentModel === "gemini-2.5-flash") {
                 currentModel = "gemini-2.0-flash-lite";
             } else {
                 throw e;
             }
          }
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }

      res.json({ text: responseText });
    } catch (error: any) {
      console.error("AI Generation Error:", error);
      const is503 = error?.message?.includes("503") || error?.status === 503 || error?.code === 503;
      const is429 = error?.message?.includes("429") || error?.status === 429 || error?.code === 429;
      
      let errorMessage = "Failed to generate analysis";
      let statusCode = 500;
      
      if (is503) {
        statusCode = 503;
        errorMessage = "اے آئی ماڈلز پر اس وقت زیادہ لوڈ ہے۔ براہ کرم کچھ دیر بعد دوبارہ کوشش کریں۔ (High Demand - 503)";
      } else if (is429) {
        statusCode = 429;
        errorMessage = "گوگل جیمنائی اے آئی (Gemini API) کی مفت استعمال کی حد عارضی طور پر مکمل ہو گئی ہے۔ براہ کرم 1 منٹ انتظار کر کے دوبارہ کوشش کریں۔ (Quota Exceeded - 429)";
      }
      
      res.status(statusCode).json({ error: errorMessage });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    // Dynamic import to avoid requiring vite in production
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
