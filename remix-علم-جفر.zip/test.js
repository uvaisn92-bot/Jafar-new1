console.log(__dirname);
